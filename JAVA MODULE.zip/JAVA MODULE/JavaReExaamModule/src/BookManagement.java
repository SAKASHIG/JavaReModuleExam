import java.util.ArrayList;
import java.util.Scanner;

class BooKSystem {
    private String id;
    private String title;
    private String author;
    private int copiesAvail;

    public BooKSystem(String id, String title, String author, int copiesAvail) {
        this.id = id;
        this.title = title;
        this.author = author;
        this.copiesAvail = copiesAvail;
    }

    public String getId() {
        return id;
    }

    public String getTitle() {
        return title;
    }

    public String getAuthor() {
        return author;
    }

    public int getCopiesAvail() {
        return copiesAvail;
    }

    @Override
    public String toString() {
        return "ID: " + id + ", Title: " + title + ", Author: " + author + ", Copies Available: " + copiesAvail;
    }
}

public class BookManagement {
	
    static ArrayList<BooKSystem> books = new ArrayList<>();
   static Scanner scanner = new Scanner(System.in);
    

    public static void main(String[] args) {
    	
        while (true) {
            System.out.println("\nLibrary Management System");
            System.out.println("1. Add a new book");
            System.out.println("2. Remove a book");
            System.out.println("3. Find all books by a given author");
            System.out.println("4. Find all books with fewer than a given number of copies available");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    addBook();
                    break;
                case 2:
                    removeBook();
                    break;
                case 3:
                    findBooksByAuthor();
                    break;
                case 4:
                    findBooksWithFewerCopies();
                    break;
                case 5:
                    System.out.println("GOOD BYEEE!!!!! TATAAAAA");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void addBook() {
        System.out.print("Enter book ID: ");
        String id = scanner.nextLine();
        System.out.print("Enter book title: ");
        String title = scanner.nextLine();
        System.out.print("Enter book author: ");
        String author = scanner.nextLine();
        System.out.print("Enter number of copies available: ");
        int copiesAvail = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        BooKSystem newBook = new BooKSystem(id, title, author, copiesAvail);
        books.add(newBook);
        System.out.println("Book added successfully.");
    }

    private static void removeBook() {
        System.out.print("Enter book ID to remove: ");
        String id = scanner.nextLine();

        boolean removed = books.removeIf(book -> book.getId().equals(id));
        if (removed) {
            System.out.println("Book removed successfully.");
        } else {
            System.out.println("Book not found.");
        }
    }

    private  static void findBooksByAuthor() {
        System.out.print("Enter author name: ");
        String author = scanner.nextLine();

        boolean found = false;
        for (BooKSystem book : books) {
            if (book.getAuthor().equalsIgnoreCase(author)) {
                System.out.println(book);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books found by the author.");
        }
    }

    private static void findBooksWithFewerCopies() {
        System.out.print("Enter the number of copies: ");
        int copies = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        boolean found = false;
        for (BooKSystem book : books) {
            if (book.getCopiesAvail() < copies) {
                System.out.println(book);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No books found with fewer than " + copies + " copies are available in the management.");
        }
    }
}
