class Person {

	String Name;
	int Age;

	public Person(String Name, int Age) {
		this.Name = Name;
		this.Age = Age;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public int getAge() {
		return Age;
	}

	public void setAge(int age) {
		Age = age;
	}

}

class Patient extends Person {

	int Id;
	String ailment;

	public Patient(String Name, int Age) {
		super(Name, Age);
	}

	public Patient(String Name, int Age, int id, String ailment) {
		super(Name, Age);
		Id = id;
		ailment = ailment;
	}

	public int getId() {
		return Id;
	}

	public void setId(int id) {
		Id = id;
	}

	public String getAilment() {
		return ailment;
	}

	public void setAilment(String ailment) {
		ailment = ailment;
	}

}

public class ContructorChaining {
	public static void main(String[] args) {

		Patient e1 = new Patient("Sakshi Gajjalwar",25);
		System.out.println(e1.getAge());
		System.out.println(e1.getName());
		
		

		
		Patient e2 = new Patient("Stephen Hawkings",56,5394,"Paralyzed");
		System.out.println(e2.getAge());
		System.out.println(e2.getName());
		System.out.println(e2.getId());
		System.out.println(e2.getAilment());
	}

}
