import java.util.HashMap;
import java.util.Map;

class ItemNotFoundException extends Exception {
    public ItemNotFoundException(String message) {
        super(message);
    }
}

class InsufficientStockException extends Exception {
    public InsufficientStockException(String message) {
        super(message);
    }
}

class InvalidQuantityException extends Exception {
    public InvalidQuantityException(String message) {
        super(message);
    }
}

class Inventory {
    private Map<String, Integer> items;

    public Inventory() {
        this.items = new HashMap<>();
    }

    public void addItem(String itemName, int quantity) throws InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException("Invalid quantity: " + quantity);
        }
        items.put(itemName, items.getOrDefault(itemName, 0) + quantity);
    }

    public void removeItem(String itemName, int quantity) throws ItemNotFoundException, InsufficientStockException, InvalidQuantityException {
        if (quantity <= 0) {
            throw new InvalidQuantityException("Invalid quantity: " + quantity);
        }
        if (!items.containsKey(itemName)) {
            throw new ItemNotFoundException("Item not found: " + itemName);
        }
        if (items.get(itemName) < quantity) {
            throw new InsufficientStockException("Insufficient stock for item: " + itemName);
        }
        items.put(itemName, items.get(itemName) - quantity);
    }

    public int getStock(String itemName) throws ItemNotFoundException {
        if (!items.containsKey(itemName)) {
            throw new ItemNotFoundException("Item not found: " + itemName);
        }
        return items.get(itemName);
    }
}

public class CustomException {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();

        try {
            inventory.addItem("Laptop",1799);
            inventory.addItem("Mouse", 499);

            System.out.println("Stock of Laptop: " + inventory.getStock("Laptop"));
            System.out.println("Stock of Mouse: " + inventory.getStock("Mouse"));

            inventory.removeItem("Laptop",200);
            System.out.println("Stock of Laptop after removal: " + inventory.getStock("Laptop"));

            inventory.removeItem("Keyboard", 110); // Should throw ItemNotFoundException
        } catch (ItemNotFoundException e) {
            System.err.println(e.getMessage());
        } catch (InsufficientStockException e) {
            System.err.println(e.getMessage());
        } catch (InvalidQuantityException e) {
            System.err.println(e.getMessage());
        }

        try {
            inventory.removeItem("Mouse", 50); // Should throw InsufficientStockException
        } catch (ItemNotFoundException e) {
            System.err.println(e.getMessage());
        } catch (InsufficientStockException e) {
            System.err.println(e.getMessage());
        } catch (InvalidQuantityException e) {
            System.err.println(e.getMessage());
        }

        try {
            inventory.addItem("Monitor", -20); // Should throw InvalidQuantityException
        } catch (InvalidQuantityException e) {
            System.err.println(e.getMessage());
        }
    }
}
